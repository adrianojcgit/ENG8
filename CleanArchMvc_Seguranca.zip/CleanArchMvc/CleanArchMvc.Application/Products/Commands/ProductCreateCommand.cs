﻿namespace CleanArchMvc.Application.Products.Commands
{
    public class ProductCreateCommand : ProductCommand
    {
    }
}
