﻿using Microsoft.AspNetCore.Identity;

namespace CleanArchMvc.Infra.Data.Identity
{
    public class ApplicationUser : IdentityUser
    {
    }
}
